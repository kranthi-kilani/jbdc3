package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Loan_master")
public class Loan {
	@Id
	private int loanId;
	private String customerName;
	private double loanAmnt;
	
	@OneToMany(cascade=CascadeType.ALL)
	 private List<Repayment> rList=new ArrayList<>();
	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customerName=" + customerName
				+ ", loanAmnt=" + loanAmnt + ", rList=" + rList + "]";
	}
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getLoanAmnt() {
		return loanAmnt;
	}
	public void setLoanAmnt(double loanAmnt) {
		this.loanAmnt = loanAmnt;
	}
	public List<Repayment> getrList() {
		return rList;
	}
	public void setrList(List<Repayment> rList) {
		this.rList = rList;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + loanId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		if (loanId != other.loanId)
			return false;
		return true;
	}
	
	public void addRepayment(Repayment rp){
		this.rList.add(rp);
	}

}
