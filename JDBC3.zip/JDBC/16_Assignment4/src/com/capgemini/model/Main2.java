package com.capgemini.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Loan loan;
		loan=em.find(Loan.class, 100);
		System.out.println(loan);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		
	}

}
