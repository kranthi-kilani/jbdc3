package com.training.client;

public class Test3 extends Thread {
	@Override
	public void run(){
		
	}

}
