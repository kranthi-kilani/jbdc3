package com.training.client;

@Table(name = "customer")

public class Customer {
    @Id
	int id;
	
	@Column(name="name",size=25,notNull=true)
	String name;
	@Column(name="Vizag",size=35,notNull=true)
	String city;

	double outStandingAmount;

}
