package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Employee emp=null;
		
		emp=em.find(Employee.class, 2);
		System.out.println(emp);
		System.out.println(emp instanceof Employee);
		System.out.println(emp instanceof Manager);
		System.out.println(emp instanceof ContractEmployee);
		if(emp instanceof Employee){
			//Employee e=(Employee) emp;
					System.out.println(emp.getEmployeeId()+" "+emp.getName()+" "+emp.getSalary());
		}
		
		if(emp instanceof Manager){
			Manager m=(Manager) emp;
			System.out.println(m.getDepartmentName());
			System.out.println(m.getEmployeeId()+" "+m.getName()+" "+m.getSalary());
		}
		if(emp instanceof ContractEmployee){
			ContractEmployee ce=(ContractEmployee) emp;
					System.out.println(ce.getEmployeeId()+" "+ce.getName()+" "+ce.getSalary()+" "+ce.getDuration()+" "+ce.isExtendable());
		}
		em.close();
		emf.close();
		
	}

}
