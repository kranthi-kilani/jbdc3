package com.capgemini.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.business.Customer;
import com.capgemini.db.CustomerDAO;
import com.capgemini.db.CustomerDAOImpl;

public class Main {

	private static  boolean addCustomer() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		int id=0;
		String name=null;
		String city=null;
		double amt=0.0;
		Customer customer=new Customer();
		CustomerDAO dao=new CustomerDAOImpl();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the id: ");
		id=scanner.nextInt();
		System.out.println("Enter the name: ");
	    name=scanner.next();
		System.out.println("Enter the city: ");
		city=scanner.next();
		System.out.println("Enter the amount: ");
		amt=scanner.nextDouble();
		customer.setId(id);
		customer.setCity(city);
		customer.setName(name);
		customer.setOutStandingAmount(amt);
		boolean result=dao.addCustomer(customer);
		if(result){
			System.out.println("added Successfully.........");
		}
		else{
		System.out.println("not added........");;
		}return result;

	}


	private static void displayCustomer() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		CustomerDAO dao = new CustomerDAOImpl();
		List<Customer> customerList=dao.getAllCustomers();
		//System.out.println(customer);
		for (Customer customer: customerList) {
			System.out.print(customer.getId()+" "+" ");
			System.out.print(customer.getName()+" "+" ");
			System.out.print(customer.getCity()+" "+" ");
			System.out.print(customer.getOutStandingAmount()+" "+" ");
			System.out.println();
			
		}{
			
		}

	}

	private static boolean updateCustomer() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		int id=0;
		String name="";
		String city="";
		double amt=0.0;
		Customer customer=new Customer();
		CustomerDAO dao=new CustomerDAOImpl();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the id: ");
		id=scanner.nextInt();
		System.out.println("Enter the name: ");
	    name=scanner.next();
		System.out.println("Enter the city: ");
		city=scanner.next();
		System.out.println("Enter the amount: ");
		amt=scanner.nextDouble();
		customer.setId(id);
		customer.setCity(city);
		customer.setName(name);
		customer.setOutStandingAmount(amt);
		boolean result=dao.updateCustomer(customer);
		if(result){
			System.out.println("updated Successfully.........");
		}
		else{
		System.out.println("not updated........");;
		}return result;
	}

	private static void removeCustomer() throws ClassNotFoundException,
			SQLException {
		// TODO Auto-generated method stub
		int inp_id = 0;
		CustomerDAO dao = new CustomerDAOImpl();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the id to remove");
		inp_id = scanner.nextInt();
		boolean result = dao.removeCustomer(inp_id);
		if (result == true) {
			System.out.println("record deleted sucessfully.....");

		}
	}

	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {

		System.out.println("Customer Application");
		System.out.println("---------------------------------");
		System.out.println("1.Add  New Customer");
		System.out.println("2.Update Customer");
		System.out.println("3.Display All Customer");
		System.out.println("4.Delete Customer");
		System.out.println("5.Exit");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Choice");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			addCustomer();
			break;

		case 2:
			updateCustomer();
			break;

		case 3:
			displayCustomer();
			break;

		case 4:
			removeCustomer();
			break;

		case 5:
			System.out.println("******Thank You*********");
			break;
		}

	}

}
