package com.capgemini.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main1 {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Qualification qualifi = new Qualification();
		Doctor doc = new Doctor();
		qualifi.setExperience(5);
		qualifi.setNameOfQualifi("M.B.B.S");
		doc.setFee(1000);
		doc.setName("kranthi");
		doc.setQualification(qualifi);
		em.persist(doc);
		em.getTransaction().commit();
		System.out.println("Added data to database............");
		em.close();
		emf.close();

	}

}
