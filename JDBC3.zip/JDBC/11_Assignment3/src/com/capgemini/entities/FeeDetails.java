package com.capgemini.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class FeeDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="fee_fid")
	private int fid;
	
	@Column(name="fee_totalfee")
	private double totalfee;
	
	@Column(name="fee_noOfInstallments")
	private int noOFInstallments;
	
	@OneToOne(mappedBy="feedetails")
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public double getTotalfee() {
		return totalfee;
	}
	public void setTotalfee(double totalfee) {
		this.totalfee = totalfee;
	}
	public int getNoOFInstallments() {
		return noOFInstallments;
	}
	public void setNoOFInstallments(int noOFInstallments) {
		this.noOFInstallments = noOFInstallments;
	}
	@Override
	public String toString() {
		return "FeeDetails [fid=" + fid + ", totalfee=" + totalfee
				+ ", noOFInstallments=" + noOFInstallments + "]";
	}
	
	

}
