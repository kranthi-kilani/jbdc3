package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Employee e=new Employee();
		e=em.find(Employee.class, 1001);
		System.out.println(e.getName()+" "+e.getSalary()+" "+e.getDepartment().getName());
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
