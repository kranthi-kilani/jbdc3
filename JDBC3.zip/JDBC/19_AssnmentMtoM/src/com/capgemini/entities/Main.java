package com.capgemini.entities;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		// //Bank

		Bank b1 = new Bank();
		b1.setBid(1);
		b1.setBname("SBI");
		b1.setHeadOfficeLocation("Vizag");

		Bank b2 = new Bank();
		b2.setBid(2);
		b2.setBname("UNION");
		b2.setHeadOfficeLocation("Hyderbad");

		Bank b3 = new Bank();
		b3.setBid(3);
		b3.setBname("CANADA");
		b3.setHeadOfficeLocation("Chennai");

		Bank b4 = new Bank();
		b4.setBid(4);
		b4.setBname("ICICI");
		b4.setHeadOfficeLocation("Tuni");

		Bank b5 = new Bank();
		b5.setBid(5);
		b5.setBname("KOTAK");
		b5.setHeadOfficeLocation("Mysore");

		// //customer

		Customer cus1 = new Customer();
		cus1.setId(101);
		cus1.setName("krewanthi");
		cus1.setDob(new Date());
		cus1.addBank(b4);
		cus1.addBank(b2);
		b4.addCustomer(cus1);
		b2.addCustomer(cus1);

		Customer cus2 = new Customer();
		cus2.setId(102);
		cus2.setName("Nani");
		cus2.setDob(new Date());
		cus2.addBank(b5);
		cus2.addBank(b3);
		b5.addCustomer(cus2);
		b3.addCustomer(cus2);

		Customer cus3 = new Customer();
		cus3.setId(103);
		cus3.setName("Rani");
		cus3.setDob(new Date());
		cus3.addBank(b1);
		cus3.addBank(b2);
		b1.addCustomer(cus3);
		b2.addCustomer(cus3);

		Customer cus4 = new Customer();
		cus4.setId(104);
		cus4.setName("Pinky");
		cus4.setDob(new Date());
		cus4.addBank(b3);
		cus4.addBank(b4);
		b3.addCustomer(cus4);
		b3.addCustomer(cus4);

		Customer cus5 = new Customer();
		cus5.setId(105);
		cus5.setName("meena");
		cus5.setDob(new Date());
		cus5.addBank(b4);
		cus5.addBank(b1);
		b4.addCustomer(cus5);
		b1.addCustomer(cus5);

		Customer cus6 = new Customer();
		cus6.setId(106);
		cus6.setName("Sunny");
		cus6.setDob(new Date());
		cus6.addBank(b4);
		cus6.addBank(b2);
		b4.addCustomer(cus6);
		b2.addCustomer(cus6);

		Customer cus7 = new Customer();
		cus7.setId(107);
		cus7.setName("sinky");
		cus7.setDob(new Date());
		cus7.addBank(b4);
		cus7.addBank(b1);
		b4.addCustomer(cus7);
		b1.addCustomer(cus7);

		Customer cus8 = new Customer();
		cus8.setId(108);
		cus8.setName("Anuska");
		cus8.setDob(new Date());
		cus8.addBank(b1);
		cus8.addBank(b2);
		b1.addCustomer(cus8);
		b2.addCustomer(cus8);

		Customer cus9 = new Customer();
		cus9.setId(109);
		cus9.setName("Anu");
		cus9.setDob(new Date());
		cus9.addBank(b3);
		cus9.addBank(b4);
		b3.addCustomer(cus9);
		b3.addCustomer(cus9);

		Customer cus10 = new Customer();
		cus10.setId(110);
		cus10.setName("Pinky");
		cus10.setDob(new Date());
		cus10.addBank(b5);
		cus10.addBank(b3);
		b5.addCustomer(cus10);
		b3.addCustomer(cus10);

		em.persist(cus1);
		em.persist(cus2);
		em.persist(cus3);
		em.persist(cus4);
		em.persist(cus5);
		em.persist(cus6);
		em.persist(cus7);
		em.persist(cus8);
		em.persist(cus9);
		em.persist(cus10);

		System.out.println("Added ....");

		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
