package com.capgemini.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Customer_master1")
public class Customer {
	@Id
	private int id;
	private String name;
	
	@Temporal(TemporalType.DATE)	//required for Date and Calendar Types
	@Column(name = "Customer_dob")
	private Date dob;
	
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "bank_customers", joinColumns = { @JoinColumn(name = "id") }, inverseJoinColumns = { @JoinColumn(name = "bid") })
	private List<Bank> banklist=new ArrayList<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public List<Bank> getBanklist() {
		return banklist;
	}

	public void setBanklist(List<Bank> banklist) {
		this.banklist = banklist;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", banklist=" + banklist + "]";
	}
	public void addBank(Bank bank){
		this.banklist.add(bank);
		}
	
	

}
