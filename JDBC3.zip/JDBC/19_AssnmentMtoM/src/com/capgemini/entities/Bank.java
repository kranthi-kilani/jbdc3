package com.capgemini.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Bank_master1")

public class Bank {
@Id
	private int bid;
	private String bname;
	private  String headOfficeLocation;
	
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="banklist")
	List<Customer> customerList=new ArrayList<>();
	
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getHeadOfficeLocation() {
		return headOfficeLocation;
	}
	public void setHeadOfficeLocation(String headOfficeLocation) {
		this.headOfficeLocation = headOfficeLocation;
	}
	@Override
	public String toString() {
		return "Bank [bid=" + bid + ", bname=" + bname
				+ ", headOfficeLocation=" + headOfficeLocation + "]";
	}
	public void addCustomer(Customer c){
		this.customerList.add(c);
	}
	
	
}
