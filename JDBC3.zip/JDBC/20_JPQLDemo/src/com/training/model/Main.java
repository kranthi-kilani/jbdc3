package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p1 = new Person("Kranthi", 21, 10000, 'F');
		Person p2 = new Person("Anu", 22, 20000, 'M');
		Person p3 = new Person("Priya", 23, 30000, 'M');
		Person p4 = new Person("Yashu", 24, 40000, 'F');

		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(p1);
		em.persist(p2);
		em.persist(p3);
		em.persist(p4);
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
