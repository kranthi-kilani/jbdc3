package com.cg.jpastart.entities;

import javax.persistence.Embeddable;

@Embeddable
public class SeatInfo {

	 private int totalCount;
	 private int bookedCount;
	private int availabeCount;
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getBookedCount() {
		return bookedCount;
	}
	public void setBookedCount(int bookedCount) {
		this.bookedCount = bookedCount;
	}
	public int getAvailabeCount() {
		return availabeCount;
	}
	public void setAvailabeCount(int availabeCount) {
		this.availabeCount = availabeCount;
	}
	public SeatInfo(int totalCount, int bookedCount, int availabeCount) {
		super();
		this.totalCount = totalCount;
		this.bookedCount = bookedCount;
		this.availabeCount = availabeCount;
	}
	public SeatInfo() {
		super();
	}
	@Override
	public String toString() {
		return "SeatInfo [totalCount=" + totalCount + ", bookedCount="
				+ bookedCount + ", availabeCount=" + availabeCount + "]";
	}
	
}
